/*

Author: Jesús Luna Cordero
Date : 22/04/2024
Purpose : "Hacer un ejemplo sencillo de inyección sin usar ningún framework"
*/
public class Main {
    public static void main(String[] args) {
        // Creamos una instancia de coche
        Vehiculo Seat = new Coche();
        Conductor conductorCoche = new Conductor(Seat);

        // Creamos una instancia de la moto y la pasamos al constructor de Conductor
        Vehiculo Suzuki = new Moto();
        Conductor conductorMoto = new Conductor(Suzuki);

        // El conductor del Seat conduce el coche
        conductorCoche.conducirVehiculo();

        // El conductor de la Suzuki conduce la moto
        conductorMoto.conducirVehiculo();
    }
}

//En definitiva, utilizar la interfaz para compartir metodos de conducir
//tanto la moto como el coche y asi ahorrar código para que sea mas eficiente