// Implementación concreta de Coche
public class Coche implements Vehiculo {
    @Override
    public void conducir() {
        System.out.println("Conduciendo el coche...");
    }
}