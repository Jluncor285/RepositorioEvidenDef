public class Conductor {
    private Vehiculo vehiculo;

    // Constructor que recibe una instancia de Vehiculo
    public Conductor(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }

    // metodo que se usa para conducir( el vehiculo)
    public void conducirVehiculo() {
        vehiculo.conducir();
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }
}
