package es.pildoras.pruebaannotations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("JefeDepartamento")
public class JefeDepartamento implements Maestros {
	
	
	@Autowired

	public JefeDepartamento(CreacionInforme nuevoInforme) {
		super();
		this.nuevoInforme = nuevoInforme;
	}

	@Override
	public String getTareas() {
		// TODO Auto-generated method stub
		return "Planificar y hacer curriculum";
	}

	@Override
	public String getInforme() {
		// TODO Auto-generated method stub
		//return "Informe generado por el Maestro";
		
		return nuevoInforme.getInforme();
	}
	
	private CreacionInforme nuevoInforme;
	

}
