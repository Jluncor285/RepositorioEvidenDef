package es.pildoras.pruebaannotations;

public interface Maestros {
	
	public String getTareas();
	
	public String getInforme();
	
	

}
