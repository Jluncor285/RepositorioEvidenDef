package es.pildoras.pruebaannotations;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UsoAnnotations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Cargamos el xml
		
		ClassPathXmlApplicationContext contexto=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		//pedir un bean al contenedor
		
		
		Maestros Antonio=contexto.getBean("JefeDepartamento", Maestros.class);
		
		System.out.println(Antonio.getInforme());
		System.out.println(Antonio.getTareas());
		
		
		
		//usar el bean 
		
		System.out.println(Antonio.getInforme());
		System.out.println(Antonio.getTareas());
				
				
		contexto.close();
		//cerrar el contexto

	}

}
