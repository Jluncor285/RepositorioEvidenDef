package es.pildoras.pruebaannotations;

import org.springframework.stereotype.Component;

@Component

public class InformeTrim2 implements CreacionInforme {

	@Override
	public String getInforme() {
		// TODO Auto-generated method stub
		return "Planificar segundo trimestre";
	}

}
