package es.pildoras.pruebaannotations;

import org.springframework.stereotype.Component;

@Component

public class InformeTrim3 implements CreacionInforme {

	@Override
	public String getInforme() {
		// TODO Auto-generated method stub
		return "Planificar tercer trimestre";
	}

}
