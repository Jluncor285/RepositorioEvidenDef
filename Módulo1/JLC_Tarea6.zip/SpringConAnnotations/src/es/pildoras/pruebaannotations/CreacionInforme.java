package es.pildoras.pruebaannotations;

public interface CreacionInforme {
	public String getInforme();
	

}
