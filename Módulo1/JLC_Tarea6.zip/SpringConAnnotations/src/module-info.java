/**
 * 
 */
/**
 * 
 */
module SpringConAnnotations {
	requires spring.context;
}